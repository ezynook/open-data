# วิธีการติดตั้ง Ckan Open-D
---
### ดาวน์โหลด Ckan
```bash
$ cd /home/
$ git clone https://github.com/ezynook/ckan.git
```
### สร้างไฟล์ .env จากไฟล์ .env.template ที่เตรียมไว้ให้
```bash
$ cd ~/ckan-docker
$ cp .env.template .env
```
### แก้ไขไฟล์ .env
```bash
$ vi .env
    - กำหนด Password สำหรับ Database ของ CKAN
        > POSTGRES_PASSWORD={ckan_password}
    - กำหนด Password สำหรับ Datastore
        > DATASTORE_READONLY_PASSWORD={datastore_password}
    - กำหนดชื่อ Host สำหรับ Database Postgres
        > POSTGRES_HOST=db
    - กำหนด version ของ CKAN (แก้ไขเป็น 2.9)
        > CKAN_VERSION=2.9
    - ตัวเลขกำกับ container (default)
        > PROJECT_NUMBER=1
    - กำหนด port สำหรับ Nginx (แก้ไขเป็น 80)
        > NGINX_PORT=80
    - กำหนด port สำหรับ Datapusher
        > DATAPUSHER_PORT=8800
    - กำหนด url สำหรับเว็บ (แก้ไขเป็น IP หรือ Domain)
        > DEFAULT_URL=http://{IP or Domain}
    - กำหนด CKAN Site ID (default)
        > CKAN_SITE_ID=default
    - กำหนด CKAN Port
        > CKAN_PORT=5000
    - กำหนดรายละเอียด SysAdmin ของระบบ
        > CKAN_SYSADMIN_NAME={admin_username}
        > CKAN_SYSADMIN_PASSWORD={admin_password}
        > CKAN_SYSADMIN_EMAIL={admin_email}
    - url สำหรับเชื่อมต่อกับ solr
        > CKAN_SOLR_URL=http://solr:8983/solr/ckan
    - url สำหรับเชื่อมต่อกับ redis
        > CKAN_REDIS_URL=redis://redis:6379/0
    - path สำหรับ storage ของ CKAN
        > CKAN__STORAGE_PATH=/var/lib/ckan
    - plugin ทั้งหมดที่เปิดใช้งาน
        > CKAN__PLUGINS=envvars stats image_view text_view recline_view resource_proxy webpage_view datastore xloader pdf_view dga_stats thai_gdc scheming_datasets hierarchy_display hierarchy_form dcat dcat_json_interface structured_data
    - default view
        > CKAN__VIEWS__DEFAULT_VIEWS=image_view text_view recline_view webpage_view pdf_view
```
### เริ่มการทำงานของ CKAN ด้วย docker-compose
```bash
$ docker-compose up -d --build
```
### ทดสอบเรียกใช้เว็บไซต์ผ่าน http://{Domain/IP}
### วิธีการอัพเดท docker images เมื่อมีการอัพเดท thai gdc extension
```bash
# อัพเดท docker image 
docker pull thepaeth/ckan-thai_gdc:ckan-2.9-xloader

# cd ไปยัง directory ที่เรา git clone  thai gdc docker มา
cd ~/ckan-docker

# ตรวจสอบในแน่ใจว่ามีไฟล์ docker-compose.yml อยู่
ls -la | grep docker-composer

# แก้ไข CKAN__PLUGINS ในไฟล์ .env บรรทัดด้านล่าง
CKAN__PLUGINS=envvars stats image_view text_view recline_view resource_proxy webpage_view datastore xloader pdf_view dga_stats thai_gdc scheming_datasets hierarchy_display hierarchy_form dcat dcat_json_interface structured_data

# รัน docker compose เพื่ออัพเดท image ของ container
docker-compose up -d
```